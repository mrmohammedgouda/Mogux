Mogux.ca — Marketing Site (Static)
================================

Files:
- index.html      (Landing)
- pricing.html    (Pricing)
- styles.css      (Shared CSS)
- assets/         (logo, favicon, UI screenshots)

Publish (simple):
1) Upload folder contents to hosting (Netlify / Vercel / Cloudflare Pages / cPanel).
2) Point mogux.ca and www.mogux.ca DNS to the marketing hosting.
3) App tenants on subdomains:
   - *.mogux.ca (e.g., mansour.mogux.ca) should point to the APP hosting.

Brand:
- Using the original neon logo (extracted) inside a dark brand chip to fit Light Luxury UI.


Added in v2:
- about.html
- contact.html (demo request mailto form)
- robots.txt
- sitemap.xml
- assets/og-image.png (OpenGraph)
- Company address: 232 Larry Uteck Blvd, Halifax, Nova Scotia, Canada


Preview:
- Open preview.html if your device/app cannot load the assets folder. It has embedded images.
