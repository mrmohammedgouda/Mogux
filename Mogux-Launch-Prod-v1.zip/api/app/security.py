from datetime import datetime, timedelta, timezone
from jose import jwt
from passlib.context import CryptContext
from .config import JWT_SECRET, JWT_ALG, JWT_EXP_MIN

pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(p: str) -> str:
    return pwd.hash(p)

def verify_password(p: str, ph: str) -> bool:
    return pwd.verify(p, ph)

def create_token(payload: dict) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=JWT_EXP_MIN)
    data = {**payload, "exp": exp}
    return jwt.encode(data, JWT_SECRET, algorithm=JWT_ALG)

def decode_token(token: str) -> dict:
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
