from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from datetime import datetime, timedelta, timezone
import json, secrets

from .db import Base, engine, get_db
from .models import Tenant, User, TenantState, SSOCode
from .schemas import LoginIn, TokenOut, ForgotIn, TenantCreate, TenantOut, SSOIn, SSOExchangeIn
from .security import verify_password, create_token, hash_password
from .deps import get_current_user, require_roles, get_context
from .config import PLATFORM_SUBDOMAIN

app = FastAPI(title="Mogux API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    seed_defaults()

def seed_defaults():
    db = Session(bind=engine)
    try:
        sa = db.query(User).filter(User.tenant_id==None, User.role=="superadmin").first()
        if not sa:
            sa = User(
                id="sa_1",
                tenant_id=None,
                email="admin@mogux.ca",
                name="Platform Admin",
                role="superadmin",
                password_hash=hash_password("Admin@12345"),
                is_active=1
            )
            db.add(sa)

        ten = db.query(Tenant).first()
        if not ten:
            ten = Tenant(id="t_mogu", name="Mogux Demo Company", subdomain="mogu", branding_json="{}")
            db.add(ten)
            u = User(id="u_admin_mogu", tenant_id=ten.id, email="admin@mogu.ca", name="Company Admin", role="admin",
                     password_hash=hash_password("Admin@12345"), is_active=1)
            db.add(u)
            initial = {
              "tenants":[{"id":"mogu","name":"Mogux Demo Company","subdomain":"mogu","cities":["Halifax"],"branches":["Halifax 1"]}],
              "evaluations":[],
              "sales":[],
              "ui":{"lang":"en"}
            }
            st = TenantState(tenant_id=ten.id, state_json=json.dumps(initial))
            db.add(st)

        db.commit()
    finally:
        db.close()

@app.get("/api/health")
def health():
    return {"ok": True}

@app.post("/api/auth/login", response_model=TokenOut)
def login(req: Request, data: LoginIn, db: Session = Depends(get_db)):
    ctx = get_context(req)
    email = data.email.strip().lower()

    if ctx["is_platform"]:
        user = db.query(User).filter(User.tenant_id==None, User.email==email).first()
        if not user or not verify_password(data.password, user.password_hash):
            raise HTTPException(status_code=401, detail="bad_login")
        token = create_token({"uid": user.id, "role": user.role, "tid": None, "platform": True})
        return {"access_token": token}

    ten = db.query(Tenant).filter(Tenant.subdomain==ctx["subdomain"]).first()
    if not ten:
        raise HTTPException(status_code=404, detail="tenant_not_found")

    user = db.query(User).filter(User.tenant_id==ten.id, User.email==email).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="bad_login")

    token = create_token({"uid": user.id, "role": user.role, "tid": ten.id, "platform": False, "sub": ten.subdomain})
    return {"access_token": token}

@app.post("/api/auth/forgot")
def forgot(_: ForgotIn):
    return {"ok": True}

@app.post("/api/auth/sso-exchange", response_model=TokenOut)
def sso_exchange(req: Request, body: SSOExchangeIn, db: Session = Depends(get_db)):
    ctx = get_context(req)
    if ctx["is_platform"]:
        raise HTTPException(status_code=400, detail="use_tenant_host")

    code = db.get(SSOCode, body.code)
    if not code:
        raise HTTPException(status_code=401, detail="bad_code")
    if code.expires_at < datetime.now(timezone.utc):
        db.delete(code); db.commit()
        raise HTTPException(status_code=401, detail="expired_code")

    ten = db.query(Tenant).filter(Tenant.id==code.tenant_id).first()
    if not ten or ten.subdomain != ctx["subdomain"]:
        raise HTTPException(status_code=401, detail="tenant_mismatch")

    user = db.get(User, code.user_id)
    if not user or user.role!="superadmin":
        raise HTTPException(status_code=401, detail="bad_user")

    token = create_token({"uid": user.id, "role":"superadmin", "tid": ten.id, "platform": False, "sub": ten.subdomain})
    db.delete(code); db.commit()
    return {"access_token": token}

@app.get("/api/bootstrap")
def bootstrap(req: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ctx = get_context(req)
    token_tid = getattr(req.state, "token_payload", {}).get("tid")

    # platform view
    if user.role=="superadmin" and (ctx["is_platform"] or not token_tid):
        return {"user":{"id":user.id,"email":user.email,"name":user.name,"role":user.role}, "tenant": None, "state": None}

    ten = db.query(Tenant).filter(Tenant.id==token_tid).first()
    if not ten:
        raise HTTPException(status_code=400, detail="tenant_required")
    st = db.get(TenantState, ten.id)
    state_obj = json.loads(st.state_json) if st else None
    return {
        "user":{"id":user.id,"email":user.email,"name":user.name,"role":user.role},
        "tenant":{"id":ten.id,"name":ten.name,"subdomain":ten.subdomain},
        "state": state_obj
    }

@app.get("/api/platform/tenants", response_model=list[TenantOut])
def list_tenants(user: User = Depends(require_roles("superadmin")), db: Session = Depends(get_db)):
    tenants = db.query(Tenant).order_by(Tenant.created_at.desc()).all()
    return [{"id":t.id,"name":t.name,"subdomain":t.subdomain} for t in tenants]

@app.post("/api/platform/tenants", response_model=TenantOut)
def create_tenant(body: TenantCreate, user: User = Depends(require_roles("superadmin")), db: Session = Depends(get_db)):
    sub = body.subdomain.strip().lower()
    if sub in ("www", PLATFORM_SUBDOMAIN, "api"):
        raise HTTPException(status_code=400, detail="reserved_subdomain")
    if db.query(Tenant).filter(Tenant.subdomain==sub).first():
        raise HTTPException(status_code=409, detail="subdomain_taken")

    tid = "t_" + secrets.token_urlsafe(8).replace("-","").replace("_","")
    ten = Tenant(id=tid, name=body.name.strip(), subdomain=sub, branding_json="{}")
    db.add(ten)

    initial = {
      "tenants":[{"id":sub,"name":body.name.strip(),"subdomain":sub,"cities":[],"branches":[]}],
      "evaluations":[],
      "sales":[],
      "ui":{"lang":"en"}
    }
    st = TenantState(tenant_id=tid, state_json=json.dumps(initial))
    db.add(st)

    db.commit()
    return {"id":ten.id,"name":ten.name,"subdomain":ten.subdomain}

@app.post("/api/platform/sso")
def platform_sso(body: SSOIn, user: User = Depends(require_roles("superadmin")), db: Session = Depends(get_db)):
    ten = db.query(Tenant).filter(Tenant.id==body.tenant_id).first()
    if not ten:
        raise HTTPException(status_code=404, detail="tenant_not_found")
    code = secrets.token_urlsafe(18).replace("-","").replace("_","")
    exp = datetime.now(timezone.utc) + timedelta(minutes=3)
    rec = SSOCode(code=code, tenant_id=ten.id, user_id=user.id, expires_at=exp)
    db.add(rec); db.commit()
    return {"code": code}

@app.get("/api/state")
def get_state(req: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    token_tid = getattr(req.state, "token_payload", {}).get("tid")
    if not token_tid:
        raise HTTPException(status_code=400, detail="tenant_required")
    st = db.get(TenantState, token_tid)
    return {"state": json.loads(st.state_json) if st else None}

@app.put("/api/state")
def put_state(req: Request, body: dict, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role in ("employee","shopper"):
        raise HTTPException(status_code=403, detail="forbidden")
    token_tid = getattr(req.state, "token_payload", {}).get("tid")
    if not token_tid:
        raise HTTPException(status_code=400, detail="tenant_required")

    state_payload = body.get("state")
    if isinstance(state_payload, dict) and "state" in state_payload:
        state_payload = state_payload["state"]
    if not isinstance(state_payload, dict):
        raise HTTPException(status_code=400, detail="bad_state")

    st = db.get(TenantState, token_tid)
    if not st:
        st = TenantState(tenant_id=token_tid, state_json=json.dumps(state_payload))
        db.add(st)
    else:
        st.state_json = json.dumps(state_payload)
    db.commit()
    return {"ok": True}
