from pydantic import BaseModel
from typing import Optional, Any, Dict

class LoginIn(BaseModel):
    email: str
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ForgotIn(BaseModel):
    email: str

class TenantCreate(BaseModel):
    name: str
    subdomain: str

class TenantOut(BaseModel):
    id: str
    name: str
    subdomain: str

class SSOIn(BaseModel):
    tenant_id: str

class SSOExchangeIn(BaseModel):
    code: str
