from fastapi import Depends, Header, HTTPException, Request
from sqlalchemy.orm import Session
from .db import get_db
from .security import decode_token
from .tenant import parse_host
from .models import User, Tenant

def get_context(request: Request):
    host = request.headers.get("host","")
    return parse_host(host)

def get_current_user(request: Request, db: Session = Depends(get_db), authorization: str = Header(default="")):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="missing_token")
    token = authorization.split(" ",1)[1].strip()
    try:
        payload = decode_token(token)
    except Exception:
        raise HTTPException(status_code=401, detail="bad_token")
    uid = payload.get("uid")
    if not uid:
        raise HTTPException(status_code=401, detail="bad_token")
    user = db.get(User, uid)
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="user_disabled")
    token_tenant = payload.get("tid")
    if token_tenant != user.tenant_id:
        if not (user.tenant_id is None and user.role=="superadmin" and token_tenant):
            raise HTTPException(status_code=401, detail="tenant_mismatch")
    request.state.token_payload = payload
    return user

def require_roles(*roles):
    def _r(user: User = Depends(get_current_user)):
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="forbidden")
        return user
    return _r
