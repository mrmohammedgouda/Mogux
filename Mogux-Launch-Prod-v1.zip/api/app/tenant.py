from .config import PLATFORM_SUBDOMAIN

def parse_host(host: str) -> dict:
    host = (host or "").split(":")[0].lower()
    if host in ("localhost","127.0.0.1") or host.replace(".","").isdigit():
        return {"subdomain": PLATFORM_SUBDOMAIN, "is_platform": True, "host": host}
    parts = host.split(".")
    if len(parts) < 3:
        return {"subdomain": PLATFORM_SUBDOMAIN, "is_platform": True, "host": host}
    sub = parts[0]
    is_platform = sub in (PLATFORM_SUBDOMAIN, "www")
    return {"subdomain": sub, "is_platform": is_platform, "host": host}
