import os
DATABASE_URL = os.getenv("DATABASE_URL","postgresql+psycopg://mogux:mogux@db:5432/mogux")
JWT_SECRET = os.getenv("JWT_SECRET","CHANGE_ME")
JWT_ALG = "HS256"
JWT_EXP_MIN = int(os.getenv("JWT_EXP_MIN","480"))
ROOT_DOMAIN = os.getenv("ROOT_DOMAIN","mogux.ca")
PLATFORM_SUBDOMAIN = os.getenv("PLATFORM_SUBDOMAIN","platform")
