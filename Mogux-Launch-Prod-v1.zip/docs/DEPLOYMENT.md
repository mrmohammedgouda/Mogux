# Mogux — Production Launch (Docker + Wildcard Subdomains)

## DNS
Create:
- A: mogux.ca -> Server IP
- A: platform.mogux.ca -> Server IP
- A: *.mogux.ca -> Server IP

## Run
1) Copy .env.example -> .env and set JWT_SECRET.
2) docker compose up -d --build
3) Open:
   - Marketing: http://mogux.ca
   - Platform: http://platform.mogux.ca
   - Company: http://<company>.mogux.ca

Default credentials (change immediately):
- Platform Super Admin: admin@mogux.ca / Admin@12345
- Example tenant (mogu): admin@mogu.ca / Admin@12345
